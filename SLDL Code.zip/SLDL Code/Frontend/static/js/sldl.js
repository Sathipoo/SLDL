console.log("Hello")

function reset_form() {
    document.getElementById("myForm").reset();
}